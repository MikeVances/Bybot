# from bot.core.trader import Trader
from bot.exchange.bybit_api import BybitAPI
from bot.services.telegram_bot import TelegramBot 