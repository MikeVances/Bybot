# config.py
# Конфигурационный файл торгового бота с настройками риск-менеджмента
# Функции: загрузка API ключей, настройки стратегий, лимиты рисков, системные параметры

import os
import logging

# Путь к файлу с ключами (секретами) задаётся через переменную окружения
BYBOT_API_KEY_PATH = os.getenv('BYBOT_API_KEY_PATH')
if not BYBOT_API_KEY_PATH:
    logging.error('Не задана переменная окружения BYBOT_API_KEY_PATH!')
    raise RuntimeError('Не задан путь к файлу с ключами (BYBOT_API_KEY_PATH)')

def load_keys(path):
    """Загрузка ключей из файла с валидацией"""
    keys = {}
    try:
        with open(path, 'r') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if '=' in line:
                    k, v = line.split('=', 1)
                    keys[k.strip()] = v.strip()
                else:
                    logging.warning(f"Неверный формат строки {line_num} в файле ключей: {line}")
    except FileNotFoundError:
        logging.error(f'Файл с ключами не найден: {path}')
        raise
    except Exception as e:
        logging.error(f'Ошибка при загрузке ключей: {e}')
        raise
    
    # Валидация обязательных ключей
    required_keys = ['API', 'SECRET', 'URL', 'TELEGRAM_TOKEN', 'ADMIN_USER_ID']
    missing_keys = [key for key in required_keys if not keys.get(key)]
    
    if missing_keys:
        raise ValueError(f"Отсутствуют обязательные ключи: {missing_keys}")
    
    return keys

KEYS = load_keys(BYBOT_API_KEY_PATH)

# Основные ключи (для совместимости)
BYBIT_API_KEY = KEYS["API"]
BYBIT_API_SECRET = KEYS["SECRET"]
BYBIT_API_URL = KEYS["URL"]
BYBIT_UID = KEYS.get("UID", None)  # UID для субаккаунта
TELEGRAM_TOKEN = KEYS["TELEGRAM_TOKEN"]
ADMIN_USER_ID = int(KEYS["ADMIN_USER_ID"])
ADMIN_CHAT_ID = ADMIN_USER_ID  # Используем тот же ID для chat_id

# Системные настройки
TELEGRAM_ENABLED = KEYS.get("TELEGRAM_ENABLED", "true").lower() == "true"
METRICS_ENABLED = KEYS.get("METRICS_ENABLED", "false").lower() == "true"
METRICS_PORT = int(KEYS.get("METRICS_PORT", "8000"))

# Торговые настройки
SYMBOL = KEYS.get("SYMBOL", "BTCUSDT")
TRADE_AMOUNT = float(KEYS.get("TRADE_AMOUNT", "0.001"))

# Настройки риск-менеджмента
RISK_CONFIG_PATH = KEYS.get("RISK_CONFIG_PATH", "risk_config.json")

# Глобальные лимиты рисков (могут быть переопределены в risk_config.json)
GLOBAL_RISK_LIMITS = {
    "max_daily_trades": int(KEYS.get("MAX_DAILY_TRADES", "30")),
    "max_open_positions": int(KEYS.get("MAX_OPEN_POSITIONS", "5")),
    "max_daily_loss_pct": float(KEYS.get("MAX_DAILY_LOSS_PCT", "5.0")),
    "max_position_size_pct": float(KEYS.get("MAX_POSITION_SIZE_PCT", "2.0")),
    "max_correlation_exposure": float(KEYS.get("MAX_CORRELATION_EXPOSURE", "60.0")),
    "max_drawdown_pct": float(KEYS.get("MAX_DRAWDOWN_PCT", "10.0")),
    "min_risk_reward_ratio": float(KEYS.get("MIN_RISK_REWARD_RATIO", "1.2")),
    "max_leverage": float(KEYS.get("MAX_LEVERAGE", "1.0"))
}

# Множественные API ключи для стратегий
STRATEGY_KEYS = {
    'strategy_01': {
        'api_key': KEYS.get("STRATEGY_01_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_01_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_01_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_01_AMOUNT", TRADE_AMOUNT)),
        'description': 'VolumeSpike_VWAP_Optimized',
        'enabled': KEYS.get("STRATEGY_01_ENABLED", "true").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_01_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_01_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_01_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_01_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_01_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_01_TF", "1m,5m,15m").split(",")
    },
    'strategy_02': {
        'api_key': KEYS.get("STRATEGY_02_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_02_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_02_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_02_AMOUNT", TRADE_AMOUNT)),
        'description': 'TickTimer_CumDelta_Optimized',
        'enabled': KEYS.get("STRATEGY_02_ENABLED", "true").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_02_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_02_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_02_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_02_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_02_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_02_TF", "1m,5m,15m").split(",")
    },
    'strategy_03': {
        'api_key': KEYS.get("STRATEGY_03_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_03_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_03_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_03_AMOUNT", TRADE_AMOUNT)),
        'description': 'MultiTF_VolumeSpike_Optimized',
        'enabled': KEYS.get("STRATEGY_03_ENABLED", "true").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_03_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_03_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_03_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_03_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_03_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_03_TF", "1m,5m,15m").split(",")
    },
    'strategy_04': {
        'api_key': KEYS.get("STRATEGY_04_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_04_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_04_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_04_AMOUNT", TRADE_AMOUNT)),
        'description': 'KangarooTail_Optimized',
        'enabled': KEYS.get("STRATEGY_04_ENABLED", "true").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_04_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_04_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_04_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_04_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_04_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_04_TF", "1m,5m,15m").split(",")
    },
    'strategy_05': {
        'api_key': KEYS.get("STRATEGY_05_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_05_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_05_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_05_AMOUNT", TRADE_AMOUNT)),
        'description': 'Fibonacci_RSI_Volume_Optimized',
        'enabled': KEYS.get("STRATEGY_05_ENABLED", "true").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_05_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_05_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_05_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_05_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_05_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_05_TF", "1m,5m,15m").split(",")
    },
    'strategy_06': {
        'api_key': KEYS.get("STRATEGY_06_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_06_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_06_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_06_AMOUNT", TRADE_AMOUNT)),
        'description': 'VolumeClimaxReversal_Optimized',
        'enabled': KEYS.get("STRATEGY_06_ENABLED", "true").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_06_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_06_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_06_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_06_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_06_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_06_TF", "1m,5m,15m").split(",")
    },
    'strategy_07': {
        'api_key': KEYS.get("STRATEGY_07_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_07_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_07_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_07_AMOUNT", TRADE_AMOUNT)),
        'description': 'BreakoutRetest_Optimized',
        'enabled': KEYS.get("STRATEGY_07_ENABLED", "true").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_07_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_07_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_07_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_07_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_07_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_07_TF", "1m,5m,15m").split(",")
    },
    'strategy_08': {
        'api_key': KEYS.get("STRATEGY_08_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_08_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_08_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_08_AMOUNT", TRADE_AMOUNT)),
        'description': 'Custom_Strategy_08',
        'enabled': KEYS.get("STRATEGY_08_ENABLED", "false").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_08_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_08_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_08_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_08_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_08_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_08_TF", "1m,5m,15m").split(",")
    },
    'strategy_09': {
        'api_key': KEYS.get("STRATEGY_09_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_09_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_09_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_09_AMOUNT", TRADE_AMOUNT)),
        'description': 'Custom_Strategy_09',
        'enabled': KEYS.get("STRATEGY_09_ENABLED", "false").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_09_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_09_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_09_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_09_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_09_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_09_TF", "1m,5m,15m").split(",")
    },
    'strategy_10': {
        'api_key': KEYS.get("STRATEGY_10_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("STRATEGY_10_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("STRATEGY_10_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("STRATEGY_10_AMOUNT", TRADE_AMOUNT)),
        'description': 'Custom_Strategy_10',
        'enabled': KEYS.get("STRATEGY_10_ENABLED", "false").lower() == "true",
        'risk_level': KEYS.get("STRATEGY_10_RISK", "medium"),
        'max_daily_trades': int(KEYS.get("STRATEGY_10_MAX_DAILY", "10")),
        'max_positions': int(KEYS.get("STRATEGY_10_MAX_POS", "1")),
        'stop_loss_pct': float(KEYS.get("STRATEGY_10_SL_PCT", "2.0")),
        'take_profit_pct': float(KEYS.get("STRATEGY_10_TP_PCT", "3.0")),
        'timeframes': KEYS.get("STRATEGY_10_TF", "1m,5m,15m").split(",")
    },
    'range_trading_default': {
        'api_key': KEYS.get("RANGE_TRADING_API", BYBIT_API_KEY),
        'api_secret': KEYS.get("RANGE_TRADING_SECRET", BYBIT_API_SECRET),
        'uid': KEYS.get("RANGE_TRADING_UID", BYBIT_UID),
        'trade_amount': float(KEYS.get("RANGE_TRADING_AMOUNT", "0.0005")),  # Меньший размер для частых сделок
        'description': 'Range_Trading_Sideways_Market',
        'enabled': KEYS.get("RANGE_TRADING_ENABLED", "true").lower() == "true",
        'risk_level': KEYS.get("RANGE_TRADING_RISK", "low"),
        'max_daily_trades': int(KEYS.get("RANGE_TRADING_MAX_DAILY", "50")),  # Больше сделок
        'max_positions': int(KEYS.get("RANGE_TRADING_MAX_POS", "3")),  # Больше позиций
        'stop_loss_pct': float(KEYS.get("RANGE_TRADING_SL_PCT", "1.0")),  # Узкий SL
        'take_profit_pct': float(KEYS.get("RANGE_TRADING_TP_PCT", "1.5")),  # Узкий TP
        'timeframes': KEYS.get("RANGE_TRADING_TF", "1m,5m,15m").split(",")
    }
}

def get_strategy_config(strategy_name):
    """Получить конфигурацию для конкретной стратегии с валидацией"""
    if strategy_name in STRATEGY_KEYS:
        config = STRATEGY_KEYS[strategy_name].copy()
        
        # Добавляем глобальные лимиты если не указаны индивидуально
        for limit_key, limit_value in GLOBAL_RISK_LIMITS.items():
            if limit_key not in config:
                config[limit_key] = limit_value
        
        return config
    
    # Возвращаем конфигурацию по умолчанию
    default_config = {
        'api_key': BYBIT_API_KEY,
        'api_secret': BYBIT_API_SECRET,
        'uid': BYBIT_UID,
        'trade_amount': TRADE_AMOUNT,
        'description': 'Default Strategy',
        'enabled': True,
        'risk_level': 'medium',
        'timeframes': ['1m', '5m', '15m']
    }
    
    # Добавляем глобальные лимиты
    default_config.update(GLOBAL_RISK_LIMITS)
    
    return default_config

def get_active_strategies_config():
    """Получить конфигурации только для активных стратегий"""
    active_strategies = {}
    
    for strategy_name, config in STRATEGY_KEYS.items():
        if config.get('enabled', True):
            active_strategies[strategy_name] = get_strategy_config(strategy_name)
    
    return active_strategies

def validate_strategy_config(strategy_name, config):
    """Валидация конфигурации стратегии"""
    required_fields = ['api_key', 'api_secret', 'trade_amount']
    
    for field in required_fields:
        if not config.get(field):
            raise ValueError(f"Стратегия {strategy_name}: отсутствует обязательное поле {field}")
    
    # Проверка численных значений
    if config['trade_amount'] <= 0:
        raise ValueError(f"Стратегия {strategy_name}: некорректный trade_amount")
    
    if config.get('max_daily_trades', 1) <= 0:
        raise ValueError(f"Стратегия {strategy_name}: некорректный max_daily_trades")
    
    if config.get('max_positions', 1) <= 0:
        raise ValueError(f"Стратегия {strategy_name}: некорректный max_positions")
    
    # Предупреждения для высоких значений
    if config.get('max_positions', 1) > 5:
        logging.warning(f"Стратегия {strategy_name}: большое количество максимальных позиций ({config['max_positions']})")
    
    if config.get('trade_amount', 0) > 0.01:  # 0.01 BTC = примерно $1000
        logging.warning(f"Стратегия {strategy_name}: большой размер позиции ({config['trade_amount']} BTC)")
    
    return True

def validate_all_strategies():
    """Валидация всех стратегий при запуске"""
    errors = []
    warnings = []
    
    for strategy_name in STRATEGY_KEYS.keys():
        try:
            config = get_strategy_config(strategy_name)
            validate_strategy_config(strategy_name, config)
        except ValueError as e:
            errors.append(str(e))
        except Exception as e:
            warnings.append(f"Стратегия {strategy_name}: предупреждение - {e}")
    
    if errors:
        raise ValueError(f"Ошибки конфигурации стратегий: {'; '.join(errors)}")
    
    if warnings:
        for warning in warnings:
            logging.warning(warning)
    
    logging.info(f"Валидация конфигурации завершена: {len(STRATEGY_KEYS)} стратегий проверено")

# Выполняем валидацию при импорте модуля
try:
    validate_all_strategies()
except Exception as e:
    logging.error(f"Критическая ошибка конфигурации: {e}")
    raise

# Пример обновленного файла с ключами (*.key):
"""
# Основные настройки API
API=your_bybit_api_key
SECRET=your_bybit_api_secret
URL=https://api-testnet.bybit.com
TELEGRAM_TOKEN=your_telegram_token
ADMIN_USER_ID=123456789

# Системные настройки
SYMBOL=BTCUSDT
TRADE_AMOUNT=0.001
TELEGRAM_ENABLED=true
METRICS_ENABLED=false
METRICS_PORT=8000

# Глобальные лимиты рисков
MAX_DAILY_TRADES=30
MAX_OPEN_POSITIONS=5
MAX_DAILY_LOSS_PCT=5.0
MAX_POSITION_SIZE_PCT=2.0
MAX_CORRELATION_EXPOSURE=60.0
MIN_RISK_REWARD_RATIO=1.2
MAX_LEVERAGE=1.0

# Настройки риск-менеджмента
RISK_CONFIG_PATH=risk_config.json

# Стратегия 1 - VolumeSpike VWAP (основная)
STRATEGY_01_API=your_strategy_01_api_key
STRATEGY_01_SECRET=your_strategy_01_secret
STRATEGY_01_UID=your_strategy_01_uid
STRATEGY_01_AMOUNT=0.002
STRATEGY_01_ENABLED=true
STRATEGY_01_RISK=medium
STRATEGY_01_MAX_DAILY=15
STRATEGY_01_MAX_POS=2
STRATEGY_01_SL_PCT=2.0
STRATEGY_01_TP_PCT=3.0
STRATEGY_01_TF=1m,5m,15m

# Стратегия 2 - TickTimer CumDelta
STRATEGY_02_API=your_strategy_02_api_key
STRATEGY_02_SECRET=your_strategy_02_secret
STRATEGY_02_UID=your_strategy_02_uid
STRATEGY_02_AMOUNT=0.001
STRATEGY_02_ENABLED=true
STRATEGY_02_RISK=low
STRATEGY_02_MAX_DAILY=10
STRATEGY_02_MAX_POS=1
STRATEGY_02_SL_PCT=1.5
STRATEGY_02_TP_PCT=2.5

# Стратегия 3 - MultiTF Volume (консервативная)
STRATEGY_03_ENABLED=true
STRATEGY_03_RISK=low
STRATEGY_03_MAX_DAILY=8
STRATEGY_03_AMOUNT=0.0005

# Стратегия 4 - KangarooTail (агрессивная)
STRATEGY_04_ENABLED=true
STRATEGY_04_RISK=high
STRATEGY_04_MAX_DAILY=20
STRATEGY_04_AMOUNT=0.003

# Стратегии 5-7 (включенные)
STRATEGY_05_ENABLED=true
STRATEGY_06_ENABLED=true
STRATEGY_07_ENABLED=true

# Стратегии 8-10 (отключенные по умолчанию)
STRATEGY_08_ENABLED=false
STRATEGY_09_ENABLED=false
STRATEGY_10_ENABLED=false
"""