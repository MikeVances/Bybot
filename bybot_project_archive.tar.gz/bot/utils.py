def log(message):
    print(message) 