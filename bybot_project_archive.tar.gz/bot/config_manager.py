# bot/config_manager.py
# Менеджер конфигурации для импорта настроек в другие модули
# Функции: предоставление единого интерфейса к конфигурации, совместимость с legacy кодом

import sys
import os

# Добавляем корневую директорию в путь для импорта config
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    # Импортируем все настройки из главного config.py
    from config import (
        BYBIT_API_KEY,
        BYBIT_API_SECRET, 
        BYBIT_API_URL,
        BYBIT_UID,
        TELEGRAM_TOKEN,
        ADMIN_USER_ID,
        TELEGRAM_ENABLED,
        METRICS_ENABLED,
        METRICS_PORT,
        SYMBOL,
        TRADE_AMOUNT,
        RISK_CONFIG_PATH,
        GLOBAL_RISK_LIMITS,
        STRATEGY_KEYS,
        get_strategy_config,
        get_active_strategies_config,
        validate_strategy_config,
        validate_all_strategies
    )
    
    # Создаем объект config для совместимости
    class Config:
        # API настройки
        BYBIT_API_KEY = BYBIT_API_KEY
        BYBIT_API_SECRET = BYBIT_API_SECRET
        BYBIT_API_URL = BYBIT_API_URL
        BYBIT_UID = BYBIT_UID
        
        # Telegram настройки
        TELEGRAM_TOKEN = TELEGRAM_TOKEN
        ADMIN_USER_ID = ADMIN_USER_ID
        TELEGRAM_ENABLED = TELEGRAM_ENABLED
        
        # Системные настройки
        METRICS_ENABLED = METRICS_ENABLED
        METRICS_PORT = METRICS_PORT
        
        # Торговые настройки
        SYMBOL = SYMBOL
        TRADE_AMOUNT = TRADE_AMOUNT
        
        # Риск-менеджмент
        RISK_CONFIG_PATH = RISK_CONFIG_PATH
        GLOBAL_RISK_LIMITS = GLOBAL_RISK_LIMITS
        STRATEGY_KEYS = STRATEGY_KEYS
        
        # Методы
        @staticmethod
        def get_strategy_config(strategy_name):
            return get_strategy_config(strategy_name)
        
        @staticmethod
        def get_active_strategies_config():
            return get_active_strategies_config()
        
        @staticmethod
        def validate_strategy_config(strategy_name, config):
            return validate_strategy_config(strategy_name, config)
        
        @staticmethod
        def validate_all_strategies():
            return validate_all_strategies()
    
    # Создаем экземпляр для импорта
    config = Config()
    
except ImportError as e:
    print(f"❌ Ошибка импорта конфигурации: {e}")
    print("Убедитесь, что файл config.py находится в корневой директории проекта")
    raise
except Exception as e:
    print(f"❌ Ошибка инициализации конфигурации: {e}")
    raise