# bot/services/telegram_bot.py
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from bot.exchange.bybit_api import TradingBot, BybitAPI
from bot.cli import load_active_strategy, save_active_strategy
from config import TELEGRAM_TOKEN, get_strategy_config

# Импортируем конфигурацию для ADMIN_CHAT_ID
try:
    from config import ADMIN_CHAT_ID
except ImportError:
    try:
        from config import ADMIN_USER_ID
        ADMIN_CHAT_ID = ADMIN_USER_ID
    except ImportError:
        ADMIN_CHAT_ID = None
from bot.core.trader import get_active_strategies
import pandas as pd
import os
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import CallbackQueryHandler
import glob
from datetime import datetime
import subprocess

# Отключаем подробное логирование Telegram (чтобы ключ не попадал в логи)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)
logging.getLogger("telegram.bot").setLevel(logging.WARNING)
logging.getLogger("telegram.ext").setLevel(logging.WARNING)

print("[DEBUG] telegram_bot.py загружен")

class TelegramBot:
    def __init__(self, token):
        self.token = token
        self.app = Application.builder().token(token).build()
        self._register_handlers()
    
    def _escape_markdown(self, text: str) -> str:
        """Экранирование специальных символов для MarkdownV2"""
        # Символы, которые нужно экранировать в MarkdownV2
        special_chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
        escaped_text = text
        for char in special_chars:
            escaped_text = escaped_text.replace(char, f'\\{char}')
        return escaped_text

    def _edit_message_with_keyboard(self, update, context, text, keyboard=None, parse_mode='Markdown'):
        """Универсальная функция для редактирования сообщения с клавиатурой"""
        if keyboard is None:
            keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if update.callback_query:
            return update.callback_query.edit_message_text(
                text=text,
                reply_markup=reply_markup,
                parse_mode=parse_mode
            )
        else:
            return context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=text,
                reply_markup=reply_markup,
                parse_mode=parse_mode
            )

    def _register_handlers(self):
        self.app.add_handler(CommandHandler("start", self._start))
        self.app.add_handler(CommandHandler("menu", self._menu))
        self.app.add_handler(CommandHandler("balance", self._balance))
        self.app.add_handler(CommandHandler("position", self._position))
        self.app.add_handler(CommandHandler("strategies", self._strategies))
        self.app.add_handler(CommandHandler("trades", self._trades))
        self.app.add_handler(CommandHandler("logs", self._logs))
        self.app.add_handler(CommandHandler("all_strategies", self._all_strategies))
        self.app.add_handler(CallbackQueryHandler(self._on_menu_button))
        self.app.add_handler(CallbackQueryHandler(self._on_strategy_toggle))

    def _get_strategy_list(self):
        files = glob.glob("bot/strategy/strategy_*.py")
        return [os.path.splitext(os.path.basename(f))[0] for f in files]

    async def _start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        print("[DEBUG] Получена команда /start")
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="🤖 *Мультистратегический торговый бот*\n\n"
                 "Доступные команды:\n"
                 "📊 /balance - Баланс аккаунта\n"
                 "📈 /position - Текущие позиции\n"
                 "🎯 /strategies - Управление стратегиями\n"
                 "📋 /all_strategies - Статус всех стратегий\n"
                 "📝 /trades - История сделок\n"
                 "📊 /logs - Логи бота\n"
                 "⚙️ /menu - Главное меню"
        )

    async def _balance(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать баланс аккаунта"""
        try:
            api = BybitAPI()
            balance_data = api.get_wallet_balance_v5()
            
            if balance_data and balance_data.get('retCode') == 0:
                balance_text = api.format_balance_v5(balance_data)
                keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
                
                await self._edit_message_with_keyboard(
                    update, context,
                    f"💰 *Баланс аккаунта*\n\n{balance_text}",
                    keyboard
                )
            else:
                error_msg = "❌ Не удалось получить баланс"
                if balance_data and balance_data.get('retMsg'):
                    error_msg += f"\nОшибка: {balance_data['retMsg']}"
                
                keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
                await self._edit_message_with_keyboard(
                    update, context,
                    error_msg,
                    keyboard,
                    parse_mode=None
                )
        except Exception as e:
            keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка получения баланса: {str(e)}",
                keyboard,
                parse_mode=None
            )

    async def _position(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать текущие позиции"""
        try:
            from bot.exchange.bybit_api import BybitAPI
            api = BybitAPI()
            positions = api.get_positions("BTCUSDT")
            
            if positions and positions.get('result') and positions['result'].get('list'):
                pos_list = positions['result']['list']
                position_text = "📈 *Текущие позиции:*\n\n"
                
                for pos in pos_list:
                    size = float(pos.get('size', 0))
                    if size > 0:
                        side = pos.get('side', 'Unknown')
                        avg_price = pos.get('avgPrice', '0')
                        unrealised_pnl = pos.get('unrealisedPnl', '0')
                        mark_price = pos.get('markPrice', '0')
                        
                        position_text += f"🔸 *{side}* {size} BTC\n"
                        position_text += f"   💰 Цена входа: \\${avg_price}\n"
                        position_text += f"   📊 Текущая цена: \\${mark_price}\n"
                        position_text += f"   💵 P&L: \\${unrealised_pnl}\n\n"
                
                if position_text == "📈 *Текущие позиции:*\n\n":
                    position_text += "📭 Нет открытых позиций"
                
                await self._edit_message_with_keyboard(update, context, position_text)
            else:
                await self._edit_message_with_keyboard(
                    update, context,
                    "📭 Нет открытых позиций"
                )
        except Exception as e:
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка получения позиций: {str(e)}",
                parse_mode=None
            )

    async def _all_strategies(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать статус всех стратегий"""
        try:
            # Используем новые стратегии вместо старых
            strategy_names = [
                'VolumeVWAP_v2',
                'CumDelta_SR_v2', 
                'MultiTF_Volume_v2',
                'VolumeVWAP_v2_conservative',
                'FibonacciRSI'
            ]
            status_text = f"🎯 *Статус всех стратегий (новая архитектура):*\n\n⏰ Обновлено: {datetime.now().strftime('%H:%M:%S')}\n\n"
            
            for strategy_name in strategy_names:
                config = get_strategy_config(strategy_name)
                
                # Проверяем баланс и позиции для каждой стратегии
                try:
                    api = TradingBot(
                        symbol="BTCUSDT",
                        api_key=config['api_key'],
                        api_secret=config['api_secret'],
                        uid=config['uid']
                    )
                    
                    balance_data = api.get_wallet_balance_v5()
                    if balance_data and balance_data.get('retCode') == 0:
                        coins = balance_data['result']['list'][0]['coin']
                        usdt = next((c for c in coins if c['coin'] == 'USDT'), None)
                        if usdt:
                            balance = float(usdt['walletBalance'])
                            status = "🟢 Активна" if balance >= 10 else "🔴 Недостаточно средств"
                            status_text += f"📊 *{strategy_name}*\n"
                            status_text += f"   {status}\n"
                            status_text += f"   💰 Баланс: \\${balance:.2f}\n"
                            status_text += f"   📝 {self._escape_markdown(config['description'])}\n"
                            
                            # Проверяем позиции
                            positions = api.get_positions("BTCUSDT")
                            if positions and positions.get('result') and positions['result'].get('list'):
                                pos_list = positions['result']['list']
                                open_positions = [pos for pos in pos_list if float(pos.get('size', 0)) > 0]
                                if open_positions:
                                    status_text += f"   📈 Позиций: {len(open_positions)}\n"
                                    for pos in open_positions:
                                        side = pos.get('side', 'Unknown')
                                        size = float(pos.get('size', 0))
                                        pnl = pos.get('unrealisedPnl', '0')
                                        # Экранируем pnl для Markdown
                                        pnl_escaped = self._escape_markdown(str(pnl))
                                        status_text += f"      {side}: {size} BTC \\(\\${pnl_escaped}\\)\n"
                                else:
                                    status_text += f"   📈 Позиций: 0\n"
                            else:
                                status_text += f"   📈 Позиции: Ошибка\n"
                            status_text += "\n"
                        else:
                            status_text += f"📊 *{strategy_name}*\n"
                            status_text += f"   🔴 Не найден USDT баланс\n"
                            status_text += f"   📝 {self._escape_markdown(config['description'])}\n\n"
                    else:
                        error_msg = "🔴 Ошибка API"
                        if balance_data and balance_data.get('retMsg'):
                            error_msg += f": {balance_data['retMsg']}"
                        status_text += f"📊 *{strategy_name}*\n"
                        status_text += f"   {error_msg}\n"
                        status_text += f"   📝 {self._escape_markdown(config['description'])}\n\n"
                except Exception as e:
                    status_text += f"📊 *{strategy_name}*\n"
                    status_text += f"   🔴 Ошибка: {str(e)[:50]}...\n"
                    status_text += f"   📝 {self._escape_markdown(config['description'])}\n\n"
            
            # Добавляем кнопки для детального просмотра
            keyboard = [
                [
                    InlineKeyboardButton("📊 Баланс", callback_data="balance"),
                    InlineKeyboardButton("📈 Позиции", callback_data="position")
                ],
                [
                    InlineKeyboardButton("📝 Логи стратегий", callback_data="strategy_logs"),
                    InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")
                ]
            ]
            
            await self._edit_message_with_keyboard(update, context, status_text, keyboard)
            
        except Exception as e:
            keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка получения статуса стратегий: {str(e)}",
                keyboard,
                parse_mode=None
            )

    async def _strategy_logs(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать логи всех стратегий"""
        try:
            # Используем новые стратегии вместо старых
            strategy_names = [
                'VolumeVWAP_v2',
                'CumDelta_SR_v2', 
                'MultiTF_Volume_v2',
                'VolumeVWAP_v2_conservative',
                'FibonacciRSI'
            ]
            logs_text = "📝 *Логи стратегий:*\n\n"
            
            for strategy_name in strategy_names:
                log_file = f"data/logs/strategies/{strategy_name}.log"
                if os.path.exists(log_file):
                    try:
                        with open(log_file, 'r') as f:
                            lines = f.readlines()
                            if lines:
                                last_line = lines[-1].strip()
                                logs_text += f"📊 *{strategy_name}*:\n"
                                logs_text += f"   {last_line}\n\n"
                            else:
                                logs_text += f"📊 *{strategy_name}*: Нет логов\n\n"
                    except Exception as e:
                        logs_text += f"📊 *{strategy_name}*: Ошибка чтения лога\n\n"
                else:
                    logs_text += f"📊 *{strategy_name}*: Файл лога не найден\n\n"
            
            keyboard = [
                [
                    InlineKeyboardButton("🔄 Обновить", callback_data="strategy_logs"),
                    InlineKeyboardButton("📊 Все стратегии", callback_data="all_strategies")
                ],
                [
                    InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")
                ]
            ]
            
            await self._edit_message_with_keyboard(update, context, logs_text, keyboard)
            
        except Exception as e:
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка получения логов: {str(e)}",
                parse_mode=None
            )

    async def _strategies(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать меню управления стратегиями"""
        keyboard = [
            [
                InlineKeyboardButton("📊 Статус всех стратегий", callback_data="all_strategies"),
                InlineKeyboardButton("📝 Логи стратегий", callback_data="strategy_logs")
            ],
            [
                InlineKeyboardButton("⚙️ Настройки", callback_data="settings"),
                InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")
            ]
        ]
        
        await self._edit_message_with_keyboard(
            update, context,
            "🎯 *Управление стратегиями*\n\n"
            "Выберите действие:",
            keyboard
        )

    async def _trades(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать последние сделки"""
        try:
            # Читаем журнал сделок
            journal_file = "data/trade_journal.csv"
            if os.path.exists(journal_file):
                df = pd.read_csv(journal_file)
                if not df.empty:
                    # Показываем последние 10 сделок
                    recent_trades = df.tail(10)
                    trades_text = "📋 *Последние сделки:*\n\n"
                    
                    for idx, trade in recent_trades.iterrows():
                        strategy = trade.get('strategy', 'Unknown')
                        signal = trade.get('signal', 'Unknown')
                        entry_price = trade.get('entry_price', 'Unknown')
                        stop_loss = trade.get('stop_loss', 'Unknown')
                        take_profit = trade.get('take_profit', 'Unknown')
                        comment = trade.get('comment', 'Unknown')
                        tf = trade.get('tf', 'Unknown')
                        timestamp = trade.get('timestamp', 'Unknown')
                        
                        # Форматируем цены
                        entry_str = f"\\${entry_price:.2f}" if entry_price != 'Unknown' else 'Unknown'
                        sl_str = f"\\${stop_loss:.2f}" if stop_loss != 'Unknown' else 'Unknown'
                        tp_str = f"\\${take_profit:.2f}" if take_profit != 'Unknown' else 'Unknown'
                        
                        # Форматируем timestamp
                        try:
                            if timestamp != 'Unknown' and timestamp != '99':
                                # Пробуем парсить ISO формат
                                from datetime import datetime
                                dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                                time_str = dt.strftime("%d.%m.%Y %H:%M:%S")
                            else:
                                time_str = "Неизвестно"
                        except:
                            time_str = "Неизвестно"
                        
                        # Определяем эмодзи для сигнала
                        signal_emoji = "🟢" if signal == "BUY" else "🔴" if signal == "SELL" else "⚪"
                        
                        trades_text += f"{signal_emoji} *{strategy}*\n"
                        trades_text += f"   📈 Сигнал: {signal}\n"
                        trades_text += f"   💰 Вход: {entry_str}\n"
                        trades_text += f"   🛑 SL: {sl_str}\n"
                        trades_text += f"   🎯 TP: {tp_str}\n"
                        trades_text += f"   ⏰ {tf} \\| {time_str}\n"
                        trades_text += f"   📝 {comment}\n\n"
                    
                    # Добавляем статистику
                    total_trades = len(df)
                    buy_signals = len(df[df['signal'] == 'BUY'])
                    sell_signals = len(df[df['signal'] == 'SELL'])
                    
                    trades_text += f"📊 *Статистика:*\n"
                    trades_text += f"   📈 Всего записей: {total_trades}\n"
                    trades_text += f"   🟢 Покупки: {buy_signals}\n"
                    trades_text += f"   🔴 Продажи: {sell_signals}\n"
                    
                    keyboard = [
                        [
                            InlineKeyboardButton("🔄 Обновить", callback_data="trades"),
                            InlineKeyboardButton("📊 Баланс", callback_data="balance")
                        ],
                        [
                            InlineKeyboardButton("📈 Позиции", callback_data="position"),
                            InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")
                        ]
                    ]
                    
                    await self._edit_message_with_keyboard(update, context, trades_text, keyboard)
                else:
                    keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
                    await self._edit_message_with_keyboard(
                        update, context,
                        "📭 Нет записей о сделках",
                        keyboard
                    )
            else:
                keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
                await self._edit_message_with_keyboard(
                    update, context,
                    "📭 Файл журнала сделок не найден",
                    keyboard
                )
        except Exception as e:
            keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка получения сделок: {str(e)}",
                keyboard,
                parse_mode=None
            )

    async def _logs(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать логи бота"""
        try:
            log_file = "bot.log"
            if os.path.exists(log_file):
                # Читаем последние 10 строк лога
                with open(log_file, 'r') as f:
                    lines = f.readlines()
                    if lines:
                        recent_logs = lines[-10:]
                        logs_text = "📝 *Последние записи лога:*\n\n"
                        for line in recent_logs:
                            logs_text += f"`{line.strip()}`\n"
                        
                        await self._edit_message_with_keyboard(update, context, logs_text)
                    else:
                        await self._edit_message_with_keyboard(
                            update, context,
                            "📭 Лог файл пуст"
                        )
            else:
                await self._edit_message_with_keyboard(
                    update, context,
                    "📭 Файл лога не найден"
                )
        except Exception as e:
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка чтения лога: {str(e)}",
                parse_mode=None
            )

    async def _menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать главное меню"""
        keyboard = [
            [
                InlineKeyboardButton("💰 Баланс", callback_data="balance"),
                InlineKeyboardButton("📈 Позиции", callback_data="position")
            ],
            [
                InlineKeyboardButton("🎯 Стратегии", callback_data="strategies"),
                InlineKeyboardButton("📋 Сделки", callback_data="trades")
            ],
            [
                InlineKeyboardButton("📊 Графики", callback_data="charts"),
                InlineKeyboardButton("🤖 Нейронка", callback_data="neural")
            ],
            [
                InlineKeyboardButton("📝 Логи", callback_data="logs"),
                InlineKeyboardButton("⚙️ Настройки", callback_data="settings")
            ],
            [
                InlineKeyboardButton("📊 Статус", callback_data="status"),
                InlineKeyboardButton("📊 Прометей", callback_data="prometheus")
            ]
        ]
        
        await self._edit_message_with_keyboard(
            update, context,
            "🤖 *Мультистратегический торговый бот*\n\n"
            "Выберите действие:",
            keyboard
        )

    async def _on_menu_button(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка нажатий кнопок меню"""
        query = update.callback_query
        await query.answer()
        
        if query.data == "menu_back":
            await self._menu(update, context)
        elif query.data == "balance":
            await self._balance(update, context)
        elif query.data == "position":
            await self._position(update, context)
        elif query.data == "strategies":
            await self._strategies(update, context)
        elif query.data == "trades":
            await self._trades(update, context)
        elif query.data == "logs":
            await self._logs(update, context)
        elif query.data == "all_strategies":
            await self._all_strategies(update, context)
        elif query.data == "strategy_logs":
            await self._strategy_logs(update, context)
        elif query.data == "settings":
            await self._settings(update, context)
        elif query.data == "status":
            await self._status(update, context)
        elif query.data == "charts":
            await self._charts(update, context)
        elif query.data == "neural":
            await self._neural(update, context)
        elif query.data == "prometheus":
            await self._prometheus(update, context)
        elif query.data == "stop_trading":
            await self._stop_trading(update, context)
        elif query.data == "start_trading":
            await self._start_trading(update, context)

    async def _on_strategy_toggle(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        if not query or not query.data or not query.data.startswith("toggle_strategy:"):
            return
        strategy_name = query.data.split(":", 1)[1]
        try:
            with open("bot/strategy/active_strategies.txt", "r") as f:
                strategies = [line.strip() for line in f if line.strip()]
            if strategy_name in strategies:
                strategies.remove(strategy_name)
                action = "удалена из активных"
            else:
                strategies.append(strategy_name)
                action = "добавлена в активные"
            with open("bot/strategy/active_strategies.txt", "w") as f:
                for s in strategies:
                    f.write(f"{s}\n")
            await query.answer(f"Стратегия {strategy_name} {action}.", show_alert=False)
            # Обновить меню
            await self._strategies(update, context)
        except Exception as e:
            await query.answer(f"Ошибка: {e}", show_alert=True)

    async def _settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать настройки"""
        keyboard = [
            [
                InlineKeyboardButton("🎯 Управление стратегиями", callback_data="settings_strategies"),
                InlineKeyboardButton("⚙️ Настройки риска", callback_data="settings_risk")
            ],
            [
                InlineKeyboardButton("⏰ Таймфреймы", callback_data="settings_timeframes"),
                InlineKeyboardButton("🔔 Уведомления", callback_data="settings_notifications")
            ],
            [
                InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")
            ]
        ]
        
        await self._edit_message_with_keyboard(
            update, context,
            "⚙️ *Настройки бота*\n\n"
            "Выберите раздел настроек:",
            keyboard
        )

    async def _status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать статус бота"""
        try:
            # Проверяем статус сервиса
            result = subprocess.run(['systemctl', 'is-active', 'bybot-trading.service'], 
                                 capture_output=True, text=True)
            service_status = result.stdout.strip()
            
            status_text = "📊 *Статус бота:*\n\n"
            status_text += f"🔄 Сервис торговли: {'🟢 Активен' if service_status == 'active' else '🔴 Неактивен'}\n"
            
            # Проверяем количество активных стратегий
            strategy_names = get_active_strategies()
            status_text += f"🎯 Активных стратегий: {len(strategy_names)}\n"
            
            # Проверяем размер лог файлов
            log_file = "bot.log"
            if os.path.exists(log_file):
                size = os.path.getsize(log_file) / 1024  # KB
                status_text += f"📝 Размер основного лога: {size:.1f} KB\n"
            
            keyboard = [
                [InlineKeyboardButton("🔄 Обновить", callback_data="status")],
                [InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]
            ]
            
            await self._edit_message_with_keyboard(update, context, status_text, keyboard)
            
        except Exception as e:
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка получения статуса: {str(e)}",
                parse_mode=None
            )

    async def _charts(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать аналитику торговых результатов"""
        try:
            import pandas as pd
            from datetime import datetime, timedelta
            
            journal_file = "data/trade_journal.csv"
            if not os.path.exists(journal_file):
                keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
                await self._edit_message_with_keyboard(
                    update, context,
                    "📭 Файл журнала сделок не найден",
                    keyboard
                )
                return
            
            # Читаем данные
            df = pd.read_csv(journal_file)
            if df.empty:
                keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
                await self._edit_message_with_keyboard(
                    update, context,
                    "📭 Нет данных для анализа",
                    keyboard
                )
                return
            
            # Конвертируем timestamp в datetime
            try:
                df['datetime'] = pd.to_datetime(df['timestamp'], errors='coerce')
                # Удаляем записи с неправильным timestamp
                df = df[df['datetime'].notna()]
            except:
                # Если не удалось конвертировать, используем текущее время
                df['datetime'] = datetime.now()
            
            # Фильтруем данные за последние 7 дней
            week_ago = datetime.now() - timedelta(days=7)
            df_recent = df[df['datetime'] >= week_ago]
            
            # Основная статистика
            total_trades = len(df)
            recent_trades = len(df_recent)
            
            # Статистика по сигналам
            buy_signals = len(df[df['signal'] == 'BUY'])
            sell_signals = len(df[df['signal'] == 'SELL'])
            
            # Статистика по стратегиям
            strategy_stats = df['strategy'].value_counts()
            
            # Статистика по временным фреймам
            tf_stats = df['tf'].value_counts()
            
            # Анализ последних 24 часов
            day_ago = datetime.now() - timedelta(days=1)
            df_today = df[df['datetime'] >= day_ago]
            today_trades = len(df_today)
            today_buy = len(df_today[df_today['signal'] == 'BUY'])
            today_sell = len(df_today[df_today['signal'] == 'SELL'])
            
            # Формируем отчет
            charts_text = "📊 *Аналитика торговых результатов*\n\n"
            
            # Общая статистика
            charts_text += "📈 *Общая статистика:*\n"
            charts_text += f"   📊 Всего сделок: {total_trades}\n"
            charts_text += f"   📅 За неделю: {recent_trades}\n"
            charts_text += f"   ⏰ За 24 часа: {today_trades}\n"
            charts_text += f"   🟢 Покупки: {buy_signals}\n"
            charts_text += f"   🔴 Продажи: {sell_signals}\n\n"
            
            # Статистика по стратегиям
            charts_text += "🎯 *По стратегиям:*\n"
            for strategy, count in strategy_stats.head(5).items():
                strategy_buy = len(df[(df['strategy'] == strategy) & (df['signal'] == 'BUY')])
                strategy_sell = len(df[(df['strategy'] == strategy) & (df['signal'] == 'SELL')])
                charts_text += f"   📊 {strategy}: {count} сделок\n"
                charts_text += f"      🟢 {strategy_buy} | 🔴 {strategy_sell}\n"
            
            # Статистика по таймфреймам
            charts_text += "\n⏰ *По таймфреймам:*\n"
            for tf, count in tf_stats.head(5).items():
                tf_buy = len(df[(df['tf'] == tf) & (df['signal'] == 'BUY')])
                tf_sell = len(df[(df['tf'] == tf) & (df['signal'] == 'SELL')])
                charts_text += f"   📊 {tf}: {count} сделок\n"
                charts_text += f"      🟢 {tf_buy} | 🔴 {tf_sell}\n"
            
            # Активность за последние 24 часа
            charts_text += "\n🔥 *Активность за 24 часа:*\n"
            charts_text += f"   📊 Сделок: {today_trades}\n"
            charts_text += f"   🟢 Покупки: {today_buy}\n"
            charts_text += f"   🔴 Продажи: {today_sell}\n"
            
            # Топ стратегий за день
            if not df_today.empty:
                today_strategies = df_today['strategy'].value_counts()
                charts_text += "\n🏆 *Топ стратегий за день:*\n"
                for strategy, count in today_strategies.head(3).items():
                    charts_text += f"   🥇 {strategy}: {count} сделок\n"
            
            # Информация о ценах
            if not df.empty:
                avg_entry = df['entry_price'].mean()
                avg_sl = df['stop_loss'].mean()
                avg_tp = df['take_profit'].mean()
                
                charts_text += "\n💰 *Средние цены:*\n"
                charts_text += f"   💰 Вход: ${avg_entry:.2f}\n"
                charts_text += f"   🛑 SL: ${avg_sl:.2f}\n"
                charts_text += f"   🎯 TP: ${avg_tp:.2f}\n"
            
            # Навигационные кнопки
            keyboard = [
                [
                    InlineKeyboardButton("🔄 Обновить", callback_data="charts"),
                    InlineKeyboardButton("📋 Сделки", callback_data="trades")
                ],
                [
                    InlineKeyboardButton("📊 Баланс", callback_data="balance"),
                    InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")
                ]
            ]
            
            await self._edit_message_with_keyboard(update, context, charts_text, keyboard)
            
        except Exception as e:
            keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка анализа: {str(e)}",
                keyboard,
                parse_mode=None
            )

    async def _prometheus(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать метрики Prometheus"""
        try:
            # Получаем метрики с нашего экспортера
            import requests
            import re
            from datetime import datetime
            
            metrics_url = "http://localhost:8003/metrics"
            response = requests.get(metrics_url, timeout=5)
            
            if response.status_code == 200:
                metrics_text = response.text
                
                # Парсим основные метрики
                prometheus_text = "📊 *Прометей - Мониторинг системы*\n\n"
                
                # Системные метрики
                cpu_match = re.search(r'system_cpu_percent (\d+\.?\d*)', metrics_text)
                memory_match = re.search(r'system_memory_percent (\d+\.?\d*)', metrics_text)
                disk_match = re.search(r'system_disk_percent (\d+\.?\d*)', metrics_text)
                
                if cpu_match:
                    prometheus_text += f"🖥️ CPU: {cpu_match.group(1)}%\n"
                if memory_match:
                    prometheus_text += f"💾 Память: {memory_match.group(1)}%\n"
                if disk_match:
                    prometheus_text += f"💿 Диск: {disk_match.group(1)}%\n"
                
                prometheus_text += "\n🤖 *Статус ботов:*\n"
                
                # Статус ботов
                bot_statuses = {
                    'bybot-trading_service': 'Торговый бот',
                    'bybot-telegram_service': 'Telegram бот',
                    'lerabot_service': 'LeraBot'
                }
                
                for metric, name in bot_statuses.items():
                    match = re.search(f'{metric} (\\d+)', metrics_text)
                    if match:
                        status = "🟢 Активен" if match.group(1) == "1" else "🔴 Остановлен"
                        prometheus_text += f"• {name}: {status}\n"
                
                # Торговые метрики
                signals_match = re.search(r'trading_total_signals (\d+)', metrics_text)
                if signals_match:
                    prometheus_text += f"\n📈 *Торговля:*\n"
                    prometheus_text += f"• Всего сигналов: {signals_match.group(1)}\n"
                
                # Метрики нейронной сети
                neural_bets_match = re.search(r'neural_total_bets (\d+)', metrics_text)
                neural_wins_match = re.search(r'neural_winning_bets (\d+)', metrics_text)
                neural_balance_match = re.search(r'neural_balance (\d+\.?\d*)', metrics_text)
                
                if neural_bets_match:
                    prometheus_text += f"\n🤖 *Нейронная сеть:*\n"
                    prometheus_text += f"• Всего ставок: {neural_bets_match.group(1)}\n"
                    
                    if neural_wins_match and neural_bets_match.group(1) != "0":
                        wins = int(neural_wins_match.group(1))
                        total = int(neural_bets_match.group(1))
                        win_rate = (wins / total) * 100
                        prometheus_text += f"• Выигрышных: {wins}\n"
                        prometheus_text += f"• Винрейт: {win_rate:.1f}%\n"
                    
                    if neural_balance_match:
                        prometheus_text += f"• Баланс: ${neural_balance_match.group(1)}\n"
                
                prometheus_text += f"\n⏰ Обновлено: {datetime.now().strftime('%H:%M:%S')}"
                
            else:
                prometheus_text = "❌ Ошибка получения метрик\n\nПроверьте, что экспортер метрик запущен."
                
        except Exception as e:
            prometheus_text = f"❌ Ошибка мониторинга: {str(e)[:50]}..."
        
        keyboard = [
            [
                InlineKeyboardButton("🔄 Обновить", callback_data="prometheus"),
                InlineKeyboardButton("🔙 НАЗАД", callback_data="menu")
            ]
        ]
        
        await self._edit_message_with_keyboard(update, context, prometheus_text, keyboard)

    async def _stop_trading(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Остановить торговлю"""
        try:
            result = subprocess.run(['sudo', 'systemctl', 'stop', 'bybot-trading.service'], 
                                 capture_output=True, text=True)
            
            if result.returncode == 0:
                await self._edit_message_with_keyboard(
                    update, context,
                    "🛑 *Торговля остановлена*\n\n"
                    "Сервис bybot-trading.service остановлен."
                )
            else:
                await self._edit_message_with_keyboard(
                    update, context,
                    f"❌ *Ошибка остановки*\n\n"
                    f"Не удалось остановить сервис:\n{result.stderr}",
                    parse_mode=None
                )
        except Exception as e:
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка: {str(e)}",
                parse_mode=None
            )

    async def _start_trading(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Запустить торговлю"""
        try:
            result = subprocess.run(['sudo', 'systemctl', 'start', 'bybot-trading.service'], 
                                 capture_output=True, text=True)
            
            if result.returncode == 0:
                await self._edit_message_with_keyboard(
                    update, context,
                    "▶️ *Торговля запущена*\n\n"
                    "Сервис bybot-trading.service запущен."
                )
            else:
                await self._edit_message_with_keyboard(
                    update, context,
                    f"❌ *Ошибка запуска*\n\n"
                    f"Не удалось запустить сервис:\n{result.stderr}",
                    parse_mode=None
                )
        except Exception as e:
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка: {str(e)}",
                parse_mode=None
            )

    async def _settings_risk(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Настройки риска"""
        await self._edit_message_with_keyboard(
            update, context,
            "🎯 *Настройки риска*\n\n"
            "• Размер позиции: 1% от баланса\n"
            "• Stop Loss: ATR-based (динамический)\n"
            "• Take Profit: R:R 1.5 или уровни Фибоначчи\n"
            "• Максимальный риск на сделку: 1%\n\n"
            "Настройки оптимизированы для всех стратегий."
        )

    async def _settings_timeframes(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Настройки таймфреймов"""
        await self._edit_message_with_keyboard(
            update, context,
            "⏰ *Таймфреймы*\n\n"
            "Используемые таймфреймы:\n"
            "• 1m - для быстрых сигналов\n"
            "• 5m - основной таймфрейм\n"
            "• 15m - для Strategy_05\n"
            "• 1h - для определения тренда\n\n"
            "Все стратегии используют мультитаймфреймовый анализ."
        )

    async def _settings_strategies(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Настройки стратегий"""
        strategy_names = get_active_strategies()
        strategies_text = "🎯 *Активные стратегии:*\n\n"
        
        for strategy_name in strategy_names:
            config = get_strategy_config(strategy_name)
            strategies_text += f"📊 *{strategy_name}*\n"
            strategies_text += f"   📝 {config['description']}\n\n"
        
        strategies_text += "Все стратегии работают параллельно с оптимизированными SL/TP."
        
        await self._edit_message_with_keyboard(update, context, strategies_text)

    async def _settings_notifications(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Настройки уведомлений"""
        await self._edit_message_with_keyboard(
            update, context,
            "🔔 *Уведомления*\n\n"
            "• Уведомления о сигналах стратегий\n"
            "• Уведомления об открытии/закрытии позиций\n"
            "• Уведомления об ошибках\n"
            "• Статус всех стратегий\n\n"
            "Все уведомления отправляются в этот чат."
        )

    async def _neural(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать информацию о нейронной сети"""
        try:
            from bot.ai import NeuralIntegration
            
            # Инициализируем нейронную интеграцию
            neural_integration = NeuralIntegration()
            
            # Получаем статистику
            stats = neural_integration.get_neural_statistics()
            neural_stats = stats['neural_trader']
            strategy_analysis = stats['strategy_analysis']
            
            # Формируем отчет
            neural_text = "🤖 *Нейронная сеть-трейдер*\n\n"
            
            # Статистика нейронки
            neural_text += "📊 *Статистика нейронки:*\n"
            neural_text += f"   💰 Баланс: \\${neural_stats['current_balance']:.2f}\n"
            neural_text += f"   📈 Прибыль: \\${neural_stats['profit']:.2f}\n"
            neural_text += f"   📊 ROI: {neural_stats['roi']:.1f}%\n"
            neural_text += f"   🎯 Ставок: {neural_stats['total_bets']}\n"
            neural_text += f"   ✅ Успешных: {neural_stats['winning_bets']}\n"
            neural_text += f"   📈 Винрейт: {neural_stats['win_rate']:.1f}%\n\n"
            
            # Ранжирование стратегий
            ranking = neural_integration.get_strategy_ranking()
            if ranking:
                neural_text += "🏆 *Ранжирование стратегий:*\n"
                for i, strategy in enumerate(ranking[:5], 1):
                    strategy_name = strategy['strategy'].replace('_', '\\_')
                    neural_text += f"   {i}\\. {strategy_name}\n"
                    neural_text += f"      📊 Сигналов: {strategy['total_signals']}\n"
                    neural_text += f"      ✅ Успешность: {strategy['success_rate']*100:.1f}%\n"
                    neural_text += f"      💰 Прибыль: {strategy['avg_profit']*100:.2f}%\n"
                    neural_text += f"      🟢 Покупки: {strategy['buy_signals']} \\| 🔴 Продажи: {strategy['sell_signals']}\n\n"
            
            # Активные ставки
            neural_text += f"🔥 *Активные ставки:* {stats['active_bets']}\n"
            neural_text += f"📋 *Завершенных сделок:* {stats['completed_trades']}\n\n"
            
            # Информация о системе
            neural_text += "🧠 *Архитектура:*\n"
            neural_text += "   • Входной слой: 50 нейронов\n"
            neural_text += "   • Скрытые слои: 32 \\+ 32 нейрона\n"
            neural_text += "   • Выходной слой: 10 нейронов \\(по стратегиям\\)\n"
            neural_text += "   • Активация: ReLU \\+ Softmax\n"
            neural_text += "   • Обучение: Обратное распространение\n\n"
            
            neural_text += "🎯 *Функции:*\n"
            neural_text += "   • Анализ рыночных данных\n"
            neural_text += "   • Оценка сигналов стратегий\n"
            neural_text += "   • Предсказание успешности\n"
            neural_text += "   • Автоматические ставки\n"
            neural_text += "   • Обучение на результатах\n\n"
            
            neural_text += "📊 *Анализируемые стратегии:*\n"
            neural_text += "   • strategy\\_01 \\- VolumeSpike\\_VWAP\\_Optimized\n"
            neural_text += "   • strategy\\_02 \\- TickTimer\\_CumDelta\\_Optimized\n"
            neural_text += "   • strategy\\_03 \\- MultiTF\\_VolumeSpike\\_Optimized\n"
            neural_text += "   • strategy\\_04 \\- KangarooTail\\_Optimized\n"
            neural_text += "   • strategy\\_05 \\- Fibonacci\\_RSI\\_Volume\\_Optimized\n"
            neural_text += "   • strategy\\_06 \\- VolumeClimaxReversal\\_Optimized\n"
            neural_text += "   • strategy\\_07 \\- BreakoutRetest\\_Optimized\n"
            neural_text += "   • strategy\\_08 \\- Заглушка \\(обучение\\)\n"
            neural_text += "   • strategy\\_09 \\- Заглушка \\(обучение\\)\n"
            neural_text += "   • strategy\\_10 \\- Заглушка \\(обучение\\)\n"
            
            # Навигационные кнопки
            keyboard = [
                [
                    InlineKeyboardButton("🔄 Обновить", callback_data="neural"),
                    InlineKeyboardButton("📊 Графики", callback_data="charts")
                ],
                [
                    InlineKeyboardButton("📋 Сделки", callback_data="trades"),
                    InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")
                ]
            ]
            
            await self._edit_message_with_keyboard(update, context, neural_text, keyboard)
            
        except Exception as e:
            keyboard = [[InlineKeyboardButton("🔙 НАЗАД", callback_data="menu_back")]]
            await self._edit_message_with_keyboard(
                update, context,
                f"❌ Ошибка получения данных нейронки: {str(e)}",
                keyboard,
                parse_mode=None
            )

    def send_admin_message(self, message: str):
        """Отправка сообщения администратору"""
        try:
            import asyncio
            import threading
            
            # Получаем chat_id из конфигурации или используем дефолтный
            admin_chat_id = ADMIN_CHAT_ID
            if not admin_chat_id:
                print("[WARNING] ADMIN_CHAT_ID не настроен, сообщение не отправлено")
                return
            
            async def send_message():
                try:
                    await self.app.bot.send_message(
                        chat_id=admin_chat_id,
                        text=message,
                        parse_mode=None
                    )
                except Exception as e:
                    print(f"[ERROR] Ошибка отправки сообщения: {e}")
            
            # Запускаем в отдельном потоке с event loop
            def run_async():
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(send_message())
                    loop.close()
                except Exception as e:
                    print(f"[ERROR] Ошибка event loop: {e}")
            
            thread = threading.Thread(target=run_async)
            thread.start()
            thread.join(timeout=10)  # Ждем максимум 10 секунд
            
        except Exception as e:
            print(f"[ERROR] Ошибка send_admin_message: {e}")

    def start(self):
        """Запуск бота в текущем потоке"""
        print("[DEBUG] Запуск Telegram бота...")
        try:
            import asyncio
            
            # Создаем event loop для текущего потока
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            
            print("[DEBUG] Попытка подключения к Telegram API...")
            # Запускаем polling напрямую
            self.app.run_polling(drop_pending_updates=True, close_loop=False)
                    
        except KeyboardInterrupt:
            print("[DEBUG] Telegram бот остановлен пользователем")
        except Exception as e:
            print(f"[ERROR] Критическая ошибка Telegram бота: {e}")

if __name__ == "__main__":
    from config import TELEGRAM_TOKEN
    TelegramBot(TELEGRAM_TOKEN).start()