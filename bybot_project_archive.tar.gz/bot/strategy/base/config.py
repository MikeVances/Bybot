# bot/strategy/base/config.py
"""
Конфигурационные классы для торговых стратегий
Использует dataclass для типизированных конфигураций
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional, List, Union
import json
from pathlib import Path

from .enums import (
    MarketRegime, 
    TimeFrame, 
    LogLevel, 
    ValidationLevel,
    ConfluenceFactor
)


@dataclass
class BaseStrategyConfig:
    """
    Базовая конфигурация для всех торговых стратегий
    Содержит общие параметры, которые наследуются всеми стратегиями
    """
    
    # === ОСНОВНЫЕ ТОРГОВЫЕ ПАРАМЕТРЫ ===
    commission_pct: float = 0.055  # Комиссия биржи в процентах
    price_step: float = 0.1  # Шаг цены для округления
    atr_period: int = 14  # Период для расчета ATR
    risk_reward_ratio: float = 1.5  # Соотношение риск/прибыль
    stop_loss_atr_multiplier: float = 1.5  # Множитель ATR для стоп-лосса
    dynamic_tp: bool = True  # Использовать динамический тейк-профит
    
    # === ПАРАМЕТРЫ ФИЛЬТРАЦИИ ===
    min_volume_for_signal: float = 1000.0  # Минимальный объем для генерации сигнала
    volatility_filter: bool = True  # Включить фильтр волатильности
    max_volatility_threshold: float = 0.05  # Максимальная волатильность (5%)
    signal_strength_threshold: float = 0.6  # Минимальная сила сигнала (0-1)
    
    # === ПАРАМЕТРЫ АДАПТИВНОСТИ ===
    adaptive_parameters: bool = True  # Адаптивная настройка параметров
    confluence_required: int = 2  # Минимальное количество подтверждающих факторов
    market_regime_adaptation: bool = True  # Адаптация под рыночный режим
    
    # === ПАРАМЕТРЫ РИСК-МЕНЕДЖМЕНТА ===
    max_risk_per_trade_pct: float = 1.0  # Максимальный риск на сделку (%)
    max_daily_risk_pct: float = 5.0  # Максимальный дневной риск (%)
    max_positions: int = 1  # Максимальное количество одновременных позиций
    position_size_method: str = "fixed"  # Метод расчета размера позиции: fixed, kelly, percent
    
    # === ПАРАМЕТРЫ ВЫХОДА ===
    trailing_stop_enabled: bool = True  # Включить трейлинг стоп
    trailing_stop_activation_pct: float = 1.5  # Активация трейлинга при прибыли (%)
    max_position_duration_hours: int = 24  # Максимальная длительность позиции (часы)
    forced_exit_on_low_profit_hours: int = 24  # Принудительный выход при низкой прибыли
    
    # === ЛОГИРОВАНИЕ И ВАЛИДАЦИЯ ===
    log_level: LogLevel = LogLevel.INFO  # Уровень логирования
    validation_level: ValidationLevel = ValidationLevel.STANDARD  # Уровень валидации данных
    enable_performance_tracking: bool = True  # Включить отслеживание производительности
    
    # === МЕТАДАННЫЕ ===
    strategy_name: str = "BaseStrategy"  # Название стратегии
    strategy_version: str = "1.0.0"  # Версия стратегии
    description: str = "Базовая конфигурация стратегии"  # Описание
    author: str = "TradingBot"  # Автор стратегии
    created_at: Optional[str] = None  # Дата создания конфигурации
    
    # === ДОПОЛНИТЕЛЬНЫЕ ПАРАМЕТРЫ ===
    custom_parameters: Dict[str, Any] = field(default_factory=dict)  # Кастомные параметры
    
    def __post_init__(self):
        """Валидация конфигурации после инициализации"""
        self.validate()
        
        # Автоматическое заполнение метаданных
        if self.created_at is None:
            from datetime import datetime, timezone
            self.created_at = datetime.now(timezone.utc).isoformat()
    
    def validate(self) -> None:
        """Валидация параметров конфигурации"""
        # Проверка торговых параметров
        if self.risk_reward_ratio <= 0:
            raise ValueError("risk_reward_ratio должен быть больше 0")
        
        if self.commission_pct < 0 or self.commission_pct > 1:
            raise ValueError("commission_pct должен быть между 0 и 1")
        
        if self.price_step <= 0:
            raise ValueError("price_step должен быть больше 0")
        
        if self.atr_period < 1:
            raise ValueError("atr_period должен быть >= 1")
        
        # Проверка фильтров
        if self.signal_strength_threshold < 0 or self.signal_strength_threshold > 1:
            raise ValueError("signal_strength_threshold должен быть между 0 и 1")
        
        if self.max_volatility_threshold < 0:
            raise ValueError("max_volatility_threshold должен быть >= 0")
        
        if self.min_volume_for_signal < 0:
            raise ValueError("min_volume_for_signal должен быть >= 0")
        
        # Проверка риск-менеджмента
        if self.max_risk_per_trade_pct <= 0 or self.max_risk_per_trade_pct > 100:
            raise ValueError("max_risk_per_trade_pct должен быть между 0 и 100")
        
        if self.max_daily_risk_pct <= 0 or self.max_daily_risk_pct > 100:
            raise ValueError("max_daily_risk_pct должен быть между 0 и 100")
        
        if self.max_positions < 1:
            raise ValueError("max_positions должен быть >= 1")
        
        # Проверка confluence
        if self.confluence_required < 0:
            raise ValueError("confluence_required должен быть >= 0")
    
    def to_dict(self) -> Dict[str, Any]:
        """Конвертация конфигурации в словарь"""
        result = asdict(self)
        
        # Конвертируем enum'ы в строки
        for key, value in result.items():
            if hasattr(value, 'value'):  # Это enum
                result[key] = value.value
        
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BaseStrategyConfig':
        """Создание конфигурации из словаря"""
        # Обработка enum'ов
        if 'log_level' in data and isinstance(data['log_level'], str):
            data['log_level'] = LogLevel(data['log_level'])
        
        if 'validation_level' in data and isinstance(data['validation_level'], str):
            data['validation_level'] = ValidationLevel(data['validation_level'])
        
        return cls(**data)
    
    def save_to_file(self, filepath: Union[str, Path]) -> None:
        """Сохранение конфигурации в JSON файл"""
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
    
    @classmethod
    def load_from_file(cls, filepath: Union[str, Path]) -> 'BaseStrategyConfig':
        """Загрузка конфигурации из JSON файла"""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return cls.from_dict(data)
    
    def copy(self, **overrides) -> 'BaseStrategyConfig':
        """Создание копии конфигурации с изменениями"""
        current_dict = self.to_dict()
        current_dict.update(overrides)
        return self.from_dict(current_dict)
    
    def adapt_for_regime(self, regime: MarketRegime) -> 'BaseStrategyConfig':
        """Адаптация конфигурации под рыночный режим"""
        if not self.market_regime_adaptation:
            return self
        
        overrides = {}
        
        if regime == MarketRegime.VOLATILE:
            # В волатильном рынке - более консервативные параметры
            overrides.update({
                'stop_loss_atr_multiplier': self.stop_loss_atr_multiplier * 1.2,
                'signal_strength_threshold': min(self.signal_strength_threshold * 1.1, 0.9),
                'confluence_required': self.confluence_required + 1,
                'max_volatility_threshold': self.max_volatility_threshold * 0.8
            })
            
        elif regime == MarketRegime.TRENDING:
            # В трендовом рынке - более агрессивные параметры
            overrides.update({
                'stop_loss_atr_multiplier': self.stop_loss_atr_multiplier * 0.8,
                'risk_reward_ratio': self.risk_reward_ratio * 1.2,
                'signal_strength_threshold': max(self.signal_strength_threshold * 0.9, 0.4)
            })
            
        elif regime == MarketRegime.SIDEWAYS:
            # В боковом рынке - сбалансированные параметры
            overrides.update({
                'confluence_required': self.confluence_required + 1,
                'signal_strength_threshold': min(self.signal_strength_threshold * 1.05, 0.8)
            })
        
        return self.copy(**overrides) if overrides else self


@dataclass
class VolumeVWAPConfig(BaseStrategyConfig):
    """
    Конфигурация для VolumeSpike VWAP стратегии
    Наследует базовые параметры и добавляет специфичные
    """
    
    # === СПЕЦИФИЧНЫЕ ПАРАМЕТРЫ VWAP СТРАТЕГИИ ===
    volume_multiplier: float = 3.0  # Множитель объема для определения всплеска
    trend_period: int = 50  # Период для анализа тренда
    min_trend_slope: float = 0.0  # Минимальный наклон тренда
    
    # === VWAP ПАРАМЕТРЫ ===
    vwap_period: Optional[int] = None  # Период VWAP (None = кумулятивный)
    vwap_deviation_threshold: float = 0.002  # Порог отклонения от VWAP (0.2%)
    vwap_confirmation_bars: int = 2  # Количество баров для подтверждения VWAP сигнала
    
    # === ОБЪЕМНЫЕ ПАРАМЕТРЫ ===
    volume_sma_period: int = 20  # Период SMA для анализа объема
    volume_trend_window: int = 10  # Окно для анализа тренда объема
    min_volume_consistency: int = 3  # Минимальная последовательность объемных баров
    
    # === ДОПОЛНИТЕЛЬНЫЕ ФИЛЬТРЫ ===
    price_momentum_period: int = 5  # Период для анализа моментума цены
    volume_momentum_period: int = 5  # Период для анализа моментума объема
    
    def __post_init__(self):
        """Дополнительная валидация для VWAP стратегии"""
        super().__post_init__()
        self.strategy_name = "VolumeVWAP"
        
        # Специфичная валидация
        if self.volume_multiplier <= 1.0:
            raise ValueError("volume_multiplier должен быть > 1.0")
        
        if self.trend_period < 10:
            raise ValueError("trend_period должен быть >= 10")
        
        if self.vwap_period is not None and self.vwap_period < 5:
            raise ValueError("vwap_period должен быть >= 5 или None")


@dataclass
class CumDeltaConfig(BaseStrategyConfig):
    """
    Конфигурация для CumDelta Support/Resistance стратегии
    """
    
    # === DELTA ПАРАМЕТРЫ ===
    delta_window: int = 20  # Окно для расчета кумулятивной дельты
    min_delta_threshold: float = 100.0  # Минимальная дельта для сигнала
    delta_smoothing_period: int = 5  # Период сглаживания дельты
    delta_momentum_period: int = 5  # Период для анализа моментума дельты
    
    # === ТРЕНДОВЫЕ ПАРАМЕТРЫ ===
    trend_period: int = 50  # Период для анализа тренда
    min_trend_slope: float = 0.0  # Минимальный наклон тренда
    
    # === SUPPORT/RESISTANCE ПАРАМЕТРЫ ===
    support_window: int = 20  # Окно для поиска поддержки/сопротивления
    support_resistance_tolerance: float = 0.002  # Толерантность для S/R уровней (0.2%)
    min_touches_for_level: int = 2  # Минимальное количество касаний для валидного уровня
    level_strength_multiplier: float = 1.5  # Множитель силы уровня
    
    # === ОБЪЕМНЫЕ ПАРАМЕТРЫ ===
    volume_multiplier: float = 1.5  # Множитель объема (меньше чем в VWAP стратегии)
    volume_delta_correlation: bool = True  # Учет корреляции объема и дельты
    
    # === ДОПОЛНИТЕЛЬНЫЕ ПАРАМЕТРЫ ===
    use_enhanced_delta: bool = True  # Использовать улучшенный расчет дельты
    delta_divergence_detection: bool = True  # Детекция дивергенций дельты
    support_resistance_breakout: bool = True  # Учет пробоев S/R уровней
    
    def __post_init__(self):
        """Дополнительная валидация для CumDelta стратегии"""
        super().__post_init__()
        self.strategy_name = "CumDelta"
        
        # Специфичная валидация
        if self.delta_window < 5:
            raise ValueError("delta_window должен быть >= 5")
        
        if self.min_delta_threshold <= 0:
            raise ValueError("min_delta_threshold должен быть > 0")
        
        if self.support_window < 10:
            raise ValueError("support_window должен быть >= 10")
        
        if self.support_resistance_tolerance <= 0:
            raise ValueError("support_resistance_tolerance должен быть > 0")


@dataclass
class MultiTFConfig(BaseStrategyConfig):
    """
    Конфигурация для Multi-Timeframe стратегии
    """
    
    # === ТАЙМФРЕЙМЫ ===
    fast_tf: TimeFrame = TimeFrame.M5  # Быстрый таймфрейм
    slow_tf: TimeFrame = TimeFrame.H1  # Медленный таймфрейм
    additional_tfs: List[TimeFrame] = field(default_factory=list)  # Дополнительные ТФ
    
    # === ПАРАМЕТРЫ АНАЛИЗА ТРЕНДОВ ===
    fast_window: int = 20  # Окно для анализа быстрого ТФ
    slow_window: int = 50  # Окно для анализа медленного ТФ
    trend_strength_threshold: float = 0.001  # Порог силы тренда
    
    # === ОБЪЕМНЫЕ ПАРАМЕТРЫ ===
    volume_multiplier: float = 2.0  # Множитель объема
    volume_correlation_threshold: float = 0.6  # Порог корреляции объемов между ТФ
    volume_trend_window: int = 10  # Окно для анализа тренда объема
    
    # === СИНХРОНИЗАЦИЯ ТАЙМФРЕЙМОВ ===
    tf_sync_tolerance: int = 3  # Толерантность синхронизации ТФ (в барах)
    require_tf_alignment: bool = True  # Требовать выравнивание трендов между ТФ
    tf_confirmation_bars: int = 2  # Количество баров для подтверждения между ТФ
    
    # === ПРОДВИНУТЫЙ АНАЛИЗ ===
    advanced_trend_analysis: bool = True  # Продвинутый анализ тренда
    momentum_analysis: bool = True  # Анализ моментума между ТФ
    mtf_divergence_detection: bool = True  # Детекция дивергенций между ТФ
    
    # === ИНДИКАТОРЫ ===
    use_macd_confirmation: bool = True  # Использовать MACD для подтверждения
    macd_fast: int = 12  # Быстрая EMA для MACD
    macd_slow: int = 26  # Медленная EMA для MACD
    macd_signal: int = 9  # Сигнальная линия MACD
    
    def __post_init__(self):
        """Дополнительная валидация для MultiTF стратегии"""
        super().__post_init__()
        self.strategy_name = "MultiTimeframe"
        
        # Проверка таймфреймов
        if self.fast_tf.is_higher_than(self.slow_tf):
            raise ValueError("fast_tf должен быть меньше slow_tf")
        
        # Проверка параметров окон
        if self.fast_window >= self.slow_window:
            raise ValueError("fast_window должен быть < slow_window")
        
        if self.tf_sync_tolerance < 1:
            raise ValueError("tf_sync_tolerance должен быть >= 1")
        
        # Проверка MACD параметров
        if self.macd_fast >= self.macd_slow:
            raise ValueError("macd_fast должен быть < macd_slow")


# === ПРЕДУСТАНОВЛЕННЫЕ КОНФИГУРАЦИИ ===

def get_conservative_vwap_config() -> VolumeVWAPConfig:
    """Консервативная конфигурация для VWAP стратегии"""
    return VolumeVWAPConfig(
        volume_multiplier=4.0,
        signal_strength_threshold=0.8,
        risk_reward_ratio=1.2,
        confluence_required=3,
        max_risk_per_trade_pct=0.5,
        description="Консервативная VWAP стратегия с высокими требованиями"
    )


def get_aggressive_delta_config() -> CumDeltaConfig:
    """Агрессивная конфигурация для Delta стратегии"""
    return CumDeltaConfig(
        min_delta_threshold=50.0,
        signal_strength_threshold=0.5,
        risk_reward_ratio=2.0,
        confluence_required=1,
        max_risk_per_trade_pct=1.5,
        description="Агрессивная Delta стратегия с низкими требованиями"
    )


def get_scalping_mtf_config() -> MultiTFConfig:
    """Конфигурация для скальпинга на MultiTF"""
    return MultiTFConfig(
        fast_tf=TimeFrame.M1,
        slow_tf=TimeFrame.M5,
        volume_multiplier=3.0,
        fast_window=10,
        slow_window=20,
        max_position_duration_hours=2,
        trailing_stop_activation_pct=0.8,
        description="Скальпинговая MultiTF стратегия"
    )


# === ФАБРИЧНЫЕ ФУНКЦИИ ===

def create_config_from_preset(preset_name: str, **overrides) -> BaseStrategyConfig:
    """Создание конфигурации из предустановки с возможностью изменений"""
    presets = {
        'conservative_vwap': get_conservative_vwap_config,
        'aggressive_delta': get_aggressive_delta_config,
        'scalping_mtf': get_scalping_mtf_config
    }
    
    if preset_name not in presets:
        available = list(presets.keys())
        raise ValueError(f"Неизвестная предустановка '{preset_name}'. Доступные: {available}")
    
    config = presets[preset_name]()
    
    # Применяем изменения
    if overrides:
        return config.copy(**overrides)
    
    return config


def validate_config_compatibility(config: BaseStrategyConfig, strategy_type: str) -> bool:
    """Проверка совместимости конфигурации с типом стратегии"""
    type_mapping = {
        'volume_vwap': VolumeVWAPConfig,
        'cumdelta_sr': CumDeltaConfig,
        'multitf_volume': MultiTFConfig
    }
    
    expected_type = type_mapping.get(strategy_type)
    if expected_type is None:
        return False
    
    return isinstance(config, expected_type)


# === КОНСТАНТЫ ===

# Минимальные требования для разных типов стратегий
MIN_DATA_REQUIREMENTS = {
    'volume_vwap': 100,  # минимум 100 баров
    'cumdelta_sr': 80,   # минимум 80 баров
    'multitf_volume': 150  # минимум 150 баров (два ТФ)
}

# Рекомендуемые confluence факторы для каждого типа стратегии
RECOMMENDED_CONFLUENCE_FACTORS = {
    'volume_vwap': [
        ConfluenceFactor.VOLUME_SPIKE,
        ConfluenceFactor.PRICE_ABOVE_VWAP,
        ConfluenceFactor.BULLISH_TREND,
        ConfluenceFactor.RSI_FAVORABLE
    ],
    'cumdelta_sr': [
        ConfluenceFactor.POSITIVE_DELTA,
        ConfluenceFactor.AT_SUPPORT,
        ConfluenceFactor.BULLISH_TREND,
        ConfluenceFactor.VOLUME_SPIKE
    ],
    'multitf_volume': [
        ConfluenceFactor.TRENDS_ALIGNED_BULLISH,
        ConfluenceFactor.VOLUME_SPIKE,
        ConfluenceFactor.MOMENTUM_ALIGNED,
        ConfluenceFactor.MACD_BULLISH
    ]
}