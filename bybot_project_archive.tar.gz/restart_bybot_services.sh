#!/bin/bash

# Перезапуск сервиса bybot-trading (Telegram бот интегрирован в main.py)

sudo systemctl restart bybot-trading.service

echo "Сервис bybot-trading перезапущен (Telegram бот интегрирован)." 